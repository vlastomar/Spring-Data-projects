package softuni.exam.models.dto.xml;

import org.hibernate.validator.constraints.Length;
import softuni.exam.config.XmlLocalDateAddapter;
import softuni.exam.models.entities.Passenger;
import softuni.exam.models.entities.Plane;
import softuni.exam.models.entities.Town;

import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@XmlRootElement(name = "ticket")
@XmlAccessorType(XmlAccessType.FIELD)
public class TicketImportDto {

    @XmlElement(name = "serial-number")
    private String serialNumber;

    @XmlElement
    private BigDecimal price;

    @XmlElement(name = "take-off")
    @XmlJavaTypeAdapter(XmlLocalDateAddapter.class)
    private LocalDateTime takeOff;

    @XmlElement(name = "from-town")
    private TownImportFromTicketDto fromTown;

    @XmlElement(name = "to-town")
    private TownImportToTicketDto toTown;

    @XmlElement(name = "passenger")
    private PassengerImportTicketDto passenger;

    @XmlElement(name = "plane")
    private PlaneImportTicketDto plane;

    public TicketImportDto() {
    }

    //@Pattern(regexp = "\\w+")
    @Length(min = 2)
    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    @Min(value = 0)
    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }



    public LocalDateTime getTakeOff() {
        return takeOff;
    }

    public void setTakeOff(LocalDateTime takeOff) {
        this.takeOff = takeOff;
    }


    public TownImportFromTicketDto getFromTown() {
        return fromTown;
    }

    public void setFromTown(TownImportFromTicketDto fromTown) {
        this.fromTown = fromTown;
    }

    public TownImportToTicketDto getToTown() {
        return toTown;
    }

    public void setToTown(TownImportToTicketDto toTown) {
        this.toTown = toTown;
    }

    public PassengerImportTicketDto getPassenger() {
        return passenger;
    }

    public void setPassenger(PassengerImportTicketDto passenger) {
        this.passenger = passenger;
    }

    public PlaneImportTicketDto getPlane() {
        return plane;
    }

    public void setPlane(PlaneImportTicketDto plane) {
        this.plane = plane;
    }
}
