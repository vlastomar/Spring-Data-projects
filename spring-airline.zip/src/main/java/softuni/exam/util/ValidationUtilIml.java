package softuni.exam.util;

import javax.validation.Validator;


public class ValidationUtilIml implements ValidationUtil {
    private final Validator validator;


    public ValidationUtilIml(Validator validator) {
        this.validator = validator;
    }

    @Override
    public <T> boolean isValid(T entity) {
        return this.validator.validate(entity).isEmpty();
    }

}
