package softuni.exam.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.xml.PlaneImportDto;
import softuni.exam.models.dto.xml.PlaneImportRootDto;
import softuni.exam.models.entities.Plane;
import softuni.exam.repository.PlaneRepository;
import softuni.exam.service.PlaneService;
import softuni.exam.util.ValidationUtil;
import softuni.exam.util.XmlParser;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;

@Service
public class PlaneServiceImpl implements PlaneService {
    private final static String PLANES_PATH = "src/main/resources/files/xml/planes.xml";
    private final ModelMapper modelMapper;
    private final XmlParser xmlParser;
    private final ValidationUtil validationUtil;
    private final PlaneRepository planeRepository;

    @Autowired
    public PlaneServiceImpl(ModelMapper modelMapper, XmlParser xmlParser, ValidationUtil validationUtil, PlaneRepository planeRepository) {
        this.modelMapper = modelMapper;
        this.xmlParser = xmlParser;
        this.validationUtil = validationUtil;
        this.planeRepository = planeRepository;
    }


    @Override
    public boolean areImported() {
        return this.planeRepository.count() > 0;
    }

    @Override
    public String readPlanesFileContent() throws IOException {
        return String.join("", Files.readAllLines(Path.of(PLANES_PATH)));
    }

    @Override
    public String importPlanes() throws JAXBException {
        StringBuilder sb = new StringBuilder();
        PlaneImportRootDto planeImportRootDto = this.xmlParser.parseXml(PlaneImportRootDto.class, PLANES_PATH);

        for(PlaneImportDto plane : planeImportRootDto.getPlanes()){

            Optional<Plane> byRegisterNumber = this.planeRepository.findByRegisterNumber(plane.getRegisterNumber());

            if (this.validationUtil.isValid(plane) && byRegisterNumber.isEmpty()){
                Plane plane1 = this.modelMapper.map(plane,Plane.class);

                this.planeRepository.saveAndFlush(plane1);
                sb.append(String.
                        format("Successfully imported Plane %s",
                                plane.getRegisterNumber()))
                        .append(System.lineSeparator());

            }else {
                sb.append("Invalid Plane").append(System.lineSeparator());
            }
        }
        return sb.toString();
    }
}
