package softuni.exam.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.xml.TicketImportDto;
import softuni.exam.models.dto.xml.TicketImportRootDto;
import softuni.exam.models.entities.Passenger;
import softuni.exam.models.entities.Plane;
import softuni.exam.models.entities.Ticket;
import softuni.exam.models.entities.Town;
import softuni.exam.repository.PassengerRepository;
import softuni.exam.repository.PlaneRepository;
import softuni.exam.repository.TicketRepository;
import softuni.exam.repository.TownRepository;
import softuni.exam.service.TicketService;
import softuni.exam.util.ValidationUtil;
import softuni.exam.util.XmlParser;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Optional;

@Service
public class TicketServiceImpl implements TicketService {
    private final static String TICKETS_PATH = "src/main/resources/files/xml/tickets.xml";
    private final ModelMapper modelMapper;
    private final XmlParser xmlParser;
    private final ValidationUtil validationUtil;
    private final TicketRepository ticketRepository;
    private final TownRepository townRepository;
    private final PassengerRepository passengerRepository;
    private final PlaneRepository planeRepository;

    @Autowired
    public TicketServiceImpl(ModelMapper modelMapper, XmlParser xmlParser, ValidationUtil validationUtil, TicketRepository ticketRepository, TownRepository townRepository, PassengerRepository passengerRepository, PlaneRepository planeRepository) {
        this.modelMapper = modelMapper;
        this.xmlParser = xmlParser;
        this.validationUtil = validationUtil;
        this.ticketRepository = ticketRepository;
        this.townRepository = townRepository;
        this.passengerRepository = passengerRepository;
        this.planeRepository = planeRepository;
    }


    @Override
    public boolean areImported() {
        return this.ticketRepository.count() > 0;
    }

    @Override
    public String readTicketsFileContent() throws IOException {
        return String.join("", Files.readAllLines(Path.of(TICKETS_PATH)));
    }

    @Override
    public String importTickets() throws JAXBException {
        StringBuilder sb = new StringBuilder();

        TicketImportRootDto ticketImportRootDto =
                this.xmlParser.parseXml(TicketImportRootDto.class, TICKETS_PATH);
        for(TicketImportDto ticketImportDto : ticketImportRootDto.getTickets()){
            Optional<Ticket> bySerialNumber =
                    this.ticketRepository.findBySerialNumber(ticketImportDto.getSerialNumber());

            if (this.validationUtil.isValid(ticketImportDto) && bySerialNumber.isEmpty()){
                Ticket ticket = this.modelMapper.map(ticketImportDto,Ticket.class);

                Town fromTown = this.townRepository.findByName(ticketImportDto.getFromTown().getName());
                Town toTown = this.townRepository.findByName(ticketImportDto.getToTown().getName());
                Passenger passenger = this.passengerRepository
                        .findByEmail(ticketImportDto.getPassenger().getEmail()).get();
                Plane plane = this.planeRepository
                        .findByRegisterNumber(ticketImportDto.getPlane().getRegisterNumber()).get();
                ticket.setFrom(fromTown);
                ticket.setTo(toTown);
                ticket.setPassenger(passenger);
                ticket.setPlane(plane);

                this.ticketRepository.saveAndFlush(ticket);
                sb.append(String.format("Successfully imported Ticket %s - %s",
                        ticket.getFrom().getName(), ticket.getTo().getName()))
                        .append(System.lineSeparator());

            }else {
                sb.append("Invalid Ticket").append(System.lineSeparator());
            }
        }

        return sb.toString();
    }
}
