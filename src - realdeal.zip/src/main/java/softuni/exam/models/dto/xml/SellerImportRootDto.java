package softuni.exam.models.dto.xml;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
import java.util.Set;

@XmlRootElement(name = "sellers")
@XmlAccessorType(XmlAccessType.FIELD)
public class SellerImportRootDto {

    @XmlElement(name = "seller")
    private List<SellerImportDto> sellerImportDto;

    public SellerImportRootDto() {
    }

    public List<SellerImportDto> getSellerImportDto() {
        return sellerImportDto;
    }

    public void setSellerImportDto(List<SellerImportDto> sellerImportDto) {
        this.sellerImportDto = sellerImportDto;
    }
}
