package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.json.CarImportDto;
import softuni.exam.models.entities.Car;
import softuni.exam.repository.CarRepository;
import softuni.exam.service.CarService;
import softuni.exam.util.ValidationUtil;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Set;

@Service
public class CarServiceImpl implements CarService {
    private final static String CAR_PATH = "src/main/resources/files/json/cars.json";
    private final ModelMapper modelMapper;
    private final Gson gson;
    private final ValidationUtil validationUtil;
    private final CarRepository carRepository;

    @Autowired
    public CarServiceImpl(ModelMapper modelMapper, Gson gson, ValidationUtil validationUtil, CarRepository carRepository) {
        this.modelMapper = modelMapper;
        this.gson = gson;
        this.validationUtil = validationUtil;
        this.carRepository = carRepository;
    }



    @Override
    public boolean areImported() {
        return this.carRepository.count() > 0;
    }

    @Override
    public String readCarsFileContent() throws IOException {
        return String.join("", Files.readAllLines(Path.of(CAR_PATH)));
    }

    @Override
    public String importCars() throws IOException {
        StringBuilder sb = new StringBuilder();

        CarImportDto[] carImportDtos = this.gson.fromJson(this.readCarsFileContent(), CarImportDto[].class);

        for (CarImportDto carImportDto : carImportDtos) {
            if (this.validationUtil.isValid(carImportDto)){
                this.carRepository.saveAndFlush(this.modelMapper.map(carImportDto, Car.class));

                sb.append(String.format("Successfully imported car - %s - %s"
                        , carImportDto.getMake(), carImportDto.getModel()))
                .append(System.lineSeparator());
            }else {
                sb.append("Invalid car").append(System.lineSeparator());

            }
        }
        return sb.toString();
    }

    @Override
    public String getCarsOrderByPicturesCountThenByMake() {
        StringBuilder sb = new StringBuilder();
        Set<Car> cars = this.carRepository.exportCars();

        for(Car car :cars){
            sb.append(String.format("Car make - %s, model - %s\n" +
                            "      Kilometers - %d\n" +
                            "      Registered on - %s\n" +
                            "      Number of pictures - %d\n"
                    , car.getMake(), car.getModel(), car.getKilometers()
                    , car.getRegisteredOn(), car.getPictures().size()  ));
        }

        return sb.toString();
    }
}
